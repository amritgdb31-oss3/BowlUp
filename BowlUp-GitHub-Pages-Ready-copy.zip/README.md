# BowlUp

BowlUp is a college-project prototype for discovering local food kitchens in Agra.

## Publish with GitHub Pages
1. Create a public GitHub repository named `bowlup`.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select branch `main` and folder `/ (root)`, then save.
6. Wait for GitHub Pages to provide the public website URL.

## Prototype notes
- Demo logins and sign-ups are stored in the visitor's browser only.
- Cart and checkout are demo interactions; no real payments are processed.
- Kitchen names, menus, map locations and meal plans include sample or unverified project data.
